#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup
import os
try:
    import py2exe
except ImportError:
    pass
else:
    origIsSystemDLL = py2exe.build_exe.isSystemDLL

    def isSystemDLL(pathname):
        if os.path.basename(pathname).lower() in {
            "libfreetype-6.dll",
            "sdl_ttf.dll",
            "libogg-0.dll",
        }:
            return 0
        return origIsSystemDLL(pathname)

    py2exe.build_exe.isSystemDLL = isSystemDLL


setup(
    name='pyg.exe',
    version='1.0',
    author='Radomir Dopieralski',
    description='A binary launcher for PyGame.',
    author_email='pyg@sheep.art.pl',
    url='https://bitbucket.org/thesheep/pyg.exe',
    scripts=['pyg.py'],
    py_modules=['pyg'],
    zip_safe=True,
    install_requires=['distribute', 'pygame'],
    keywords='pygame windows launcher',
    options = {
        'py2exe': {
            'bundle_files': 1,
            'compressed': True,
            'excludes': [
                'doctest',
                'pdb',
                'unittest',
                'difflib',
                'inspect',
                'pyreadline',
                'email',
                '_ssl',
            ]
        },
    },
    windows = [
        {
            'script': "pyg.py",
            'icon_resources': [(0, "pygame.ico")],
        }
    ],
    zipfile = None,
    classifiers=[
        "Classifier: Development Status :: 5 - Production/Stable",
        "Classifier: Environment :: Win32 (MS Windows)",
        "Classifier: Intended Audience :: End Users/Desktop",
        "Classifier: License :: OSI Approved :: GNU Library or Lesser General Public License (LGPL)",
        "Classifier: Operating System :: Microsoft :: Windows",
        "Classifier: Programming Language :: Python",
        "Classifier: Programming Language :: Python :: 2.7",
        "Classifier: Topic :: Games/Entertainment",
        "Classifier: Topic :: Multimedia",
        "Classifier: Topic :: Software Development :: Build Tools",
        "Classifier: Topic :: System :: Installation/Setup",
        "Classifier: Topic :: System :: Software Distribution",
        "Classifier: Topic :: Utilities",
    ],
)

