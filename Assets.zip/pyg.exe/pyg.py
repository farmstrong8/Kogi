#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
A runner for games written in Python using the PyGame library.

Usage: %(__file__)s FILE
"""

import sys
import runpy

import pygame


if __name__ == '__main__':
    try:
        path = sys.argv[1]
    except IndexError:
        print __doc__.strip() % {'__file__': sys.argv[0]}
    else:
        runpy.run_path(path)
